import app from "./app";
import { logger } from "./lib/logger";
import { db } from "@workspace/db";
import { botSettingsTable } from "@workspace/db";
import { initBot } from "./lib/telegram";
import { startAutoAnalysis } from "./lib/cron";
import { seedInitialData } from "./lib/seed";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, async (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  // Seed initial data
  try {
    await seedInitialData();
    logger.info("Initial data seeded");
  } catch (err) {
    logger.warn({ err }, "Seed failed (may already exist)");
  }

  // Initialize Telegram bot if token is configured
  try {
    const settings = await db.select().from(botSettingsTable).limit(1);
    if (settings.length > 0 && settings[0].telegramBotToken) {
      await initBot(settings[0].telegramBotToken);
      logger.info("Telegram bot initialized");
    }

    // Start auto-analysis cron if enabled
    await startAutoAnalysis();
  } catch (err) {
    logger.warn({ err }, "Startup services initialization failed");
  }
});
