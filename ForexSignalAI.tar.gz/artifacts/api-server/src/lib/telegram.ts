import TelegramBot from "node-telegram-bot-api";
import { db } from "@workspace/db";
import { telegramSubscribersTable, botSettingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { logger } from "./logger";
import type { AnalysisResult } from "./analysis";

let botInstance: TelegramBot | null = null;
let botStartTime: Date = new Date();

export function getBotInstance(): TelegramBot | null {
  return botInstance;
}

export function getBotUptime(): string {
  const diff = Date.now() - botStartTime.getTime();
  const hours = Math.floor(diff / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  return `${hours}h ${minutes}m`;
}

export async function initBot(token: string): Promise<void> {
  if (botInstance) {
    try { botInstance.stopPolling(); } catch { /* ignore */ }
    botInstance = null;
  }

  try {
    const bot = new TelegramBot(token, { polling: false });
    botInstance = bot;
    botStartTime = new Date();

    bot.on("message", async (msg) => {
      const chatId = msg.chat.id.toString();
      const text = msg.text || "";

      if (text === "/start" || text === "/subscribe") {
        await handleSubscribe(chatId, msg.from?.username, msg.from?.first_name);
        await bot.sendMessage(chatId,
          "Welcome to ForexSignal AI! You are now subscribed to receive signals.\n\n" +
          "Commands:\n/subscribe - Subscribe to signals\n/unsubscribe - Unsubscribe\n/status - Check your status"
        );
      } else if (text === "/unsubscribe") {
        await handleUnsubscribe(chatId);
        await bot.sendMessage(chatId, "You have unsubscribed from ForexSignal AI signals.");
      } else if (text === "/status") {
        const sub = await db.select().from(telegramSubscribersTable)
          .where(eq(telegramSubscribersTable.chatId, chatId)).limit(1);
        if (sub.length > 0 && sub[0].active) {
          await bot.sendMessage(chatId, `Status: Active\nTier: ${sub[0].tier}\nSince: ${sub[0].subscribedAt.toISOString().split("T")[0]}`);
        } else {
          await bot.sendMessage(chatId, "You are not subscribed. Use /subscribe to start.");
        }
      }
    });

    logger.info("Telegram bot initialized");
  } catch (err) {
    logger.error({ err }, "Failed to init Telegram bot");
    throw err;
  }
}

async function handleSubscribe(chatId: string, username?: string, firstName?: string): Promise<void> {
  const existing = await db.select().from(telegramSubscribersTable)
    .where(eq(telegramSubscribersTable.chatId, chatId)).limit(1);

  if (existing.length > 0) {
    await db.update(telegramSubscribersTable)
      .set({ active: true })
      .where(eq(telegramSubscribersTable.chatId, chatId));
  } else {
    await db.insert(telegramSubscribersTable).values({
      chatId,
      username: username || null,
      firstName: firstName || null,
      tier: "free",
      active: true,
    });
  }
}

async function handleUnsubscribe(chatId: string): Promise<void> {
  await db.update(telegramSubscribersTable)
    .set({ active: false })
    .where(eq(telegramSubscribersTable.chatId, chatId));
}

export function formatSignalMessage(signal: AnalysisResult): string {
  const emoji = signal.direction === "BUY" ? "🟢" : "🔴";
  const arrow = signal.direction === "BUY" ? "📈" : "📇";
  const p = (n: number) => n.toFixed(n > 100 ? 2 : n > 10 ? 3 : 5);

  return [
    `${emoji} *FOREX SIGNAL ALERT*`,
    ``,
    `*Pair:* ${signal.symbol}`,
    `*Direction:* ${signal.direction} ${arrow}`,
    `*Confidence:* ${signal.confidence}%`,
    `*Session:* ${signal.session}`,
    ``,
    `*ENTRY:* \`${p(signal.entryPrice)}\``,
    `*Stop Loss:* \`${p(signal.stopLoss)}\``,
    `*Take Profit 1:* \`${p(signal.takeProfit1)}\``,
    `*Take Profit 2:* \`${p(signal.takeProfit2)}\``,
    ``,
    `*Indicators*`,
    `RSI: ${signal.rsi.toFixed(1)} | MACD: ${signal.macd > 0 ? "+" : ""}${signal.macd.toFixed(5)}`,
    `EMA50: ${p(signal.ema50)} | EMA200: ${p(signal.ema200)}`,
    `Trend: ${signal.trend}`,
    ``,
    `*Analysis:*`,
    `${signal.explanation.slice(0, 200)}`,
    ``,
    `_Generated: ${new Date(signal.generatedAt).toUTCString()}_`,
    `_ForexSignal AI Platform_`,
  ].join("\n");
}

export async function broadcastSignal(signal: AnalysisResult): Promise<{ sent: number; failed: number; total: number }> {
  if (!botInstance) {
    logger.warn("Bot not initialized, cannot broadcast signal");
    return { sent: 0, failed: 0, total: 0 };
  }

  const settings = await db.select().from(botSettingsTable).limit(1);
  if (!settings.length || !settings[0].telegramEnabled) {
    return { sent: 0, failed: 0, total: 0 };
  }

  const subscribers = await db.select().from(telegramSubscribersTable)
    .where(eq(telegramSubscribersTable.active, true));

  const message = formatSignalMessage(signal);
  let sent = 0;
  let failed = 0;

  for (const sub of subscribers) {
    try {
      await botInstance.sendMessage(sub.chatId, message, { parse_mode: "Markdown" });
      sent++;
    } catch (err) {
      logger.warn({ err, chatId: sub.chatId }, "Failed to send message");
      failed++;
    }
  }

  return { sent, failed, total: subscribers.length };
}

export async function broadcastText(message: string, tier: "all" | "free" | "premium" = "all"): Promise<{ sent: number; failed: number; total: number }> {
  if (!botInstance) return { sent: 0, failed: 0, total: 0 };

  let query = db.select().from(telegramSubscribersTable).where(eq(telegramSubscribersTable.active, true));
  const subscribers = await query;
  const filtered = tier === "all" ? subscribers : subscribers.filter((s) => s.tier === tier);

  let sent = 0;
  let failed = 0;

  for (const sub of filtered) {
    try {
      await botInstance.sendMessage(sub.chatId, message, { parse_mode: "Markdown" });
      sent++;
    } catch (err) {
      failed++;
      logger.warn({ err, chatId: sub.chatId }, "Failed to broadcast");
    }
  }

  return { sent, failed, total: filtered.length };
}
